import { screen } from '@testing-library/react';

import { Treatments } from '../Treatments';

test('renders response from query', () => {
  // write test here
});

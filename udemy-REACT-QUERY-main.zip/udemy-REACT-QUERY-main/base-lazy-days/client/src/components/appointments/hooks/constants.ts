export const APPOINTMENTS_QUERY_KEY = 'appointments';

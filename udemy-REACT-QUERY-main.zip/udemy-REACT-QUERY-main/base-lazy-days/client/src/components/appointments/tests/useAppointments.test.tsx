// import { act, renderHook } from '@testing-library/react-hooks';

// import { createWrapper } from '../../../test-utils';
import { useAppointments } from '../hooks/useAppointments';

test('filter appointments by availability', async () => {
  // test goes here
});

import { render } from '@testing-library/react';

// from https://tkdodo.eu/blog/testing-react-query#for-custom-hooks
// export const createWrapper = () => {
//   const queryClient = new QueryClient({
//     defaultOptions: defaultQueryClientOptions,
//   });
//   return ({ children }) => (
//     <QueryClientProvider client={queryClient}>{children}</QueryClientProvider>
//   );
// };
